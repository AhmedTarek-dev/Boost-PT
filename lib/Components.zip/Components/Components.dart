// ignore_for_file: non_constant_identifier_names

import 'package:flutter/cupertino.dart';

class Exercises {
  String? Name;
  String? Type;
  String? Image;
  String? Description;
  String? sets;
  String? reps;

  Exercises(
      {this.Name,
      this.Type,
      this.Image,
      this.Description,
      this.sets,
      this.reps});
}

class Nutrition {
  String? Name;
  String? Type;
  String? Image;
  String? Description;
  String? Calories;
  String? Category;

  Nutrition(
      {this.Name,
      this.Type,
      this.Image,
      this.Description,
      this.Calories,
      this.Category});
}

class Supplements {
  String? Name;
  String? Type;
  String? Image;
  String? Description;
  String? Dose;

  Supplements({this.Name, this.Type, this.Image, this.Description, this.Dose});
}

class Trainer {
  String? Name;
  String? Email;
  String? Image;
  String? PhoneNo;
  bool? isPhoneVerified;
  String? Gender;
  String? Rating;
  String? NoOfRatings;
  String? Bio;
  String? Age;
  String? ID;

  Trainer(
      {this.Name,
      this.Email,
      this.Image,
      this.PhoneNo,
      this.isPhoneVerified,
      this.Gender,
      this.Rating,
      this.NoOfRatings,
      this.Bio,
      this.Age,
      this.ID});
}

class Trainee {
  String? Name;
  String? Email;
  String? Image;
  String? PhoneNo;
  String? AssignedTrainer;
  bool? isPhoneVerified;
  String? Gender;
  String? Age;
  String? ID;

  Trainee(
      {this.Name,
      this.Email,
      this.Image,
      this.PhoneNo,
      this.AssignedTrainer,
      this.isPhoneVerified,
      this.Gender,
      this.Age,
      this.ID});
}

class DrawerButtons {
  final String? title;
  final IconData? icon;

  const DrawerButtons(this.title, this.icon);
}
